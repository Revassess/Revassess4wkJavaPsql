package com.revature.dao;

public class FlashcardRepository {
    
}