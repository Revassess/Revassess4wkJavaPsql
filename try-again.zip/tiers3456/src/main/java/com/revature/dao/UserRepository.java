package com.revature.dao;

public class UserRepository {

}