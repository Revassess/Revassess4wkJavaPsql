package com.revature.dao;

public interface CrudRepository {

}