package com.revature.exception;

public class ResourceNotfoundException {

}