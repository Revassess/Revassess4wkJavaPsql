package com.revature.exception;

public class ResourcePersistenceException {

}