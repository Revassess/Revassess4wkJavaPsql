package com.revature.servlet;

import javax.servlet.http.HttpServlet;

public class RevassessServlet extends HttpServlet {
    private static final long serialVersionUID = -2129085122858147401L;
    
}