package com.revature.model;

public class User {

}