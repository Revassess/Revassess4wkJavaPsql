package com.revature.model;

public enum Role {

}