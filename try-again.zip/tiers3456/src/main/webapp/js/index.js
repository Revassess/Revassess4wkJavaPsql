/**
 * use the provided url to receive the
 * json object and assign it to the resp
 * variable in this function. this is for 
 * testing purposes, do not change the getResp
 * function and leave the function names alone. 
 * the url for the api is:
 *  http://ec2-3-19-123-54.us-east-2.compute.amazonaws.com:9999/flashcard
 */
window.addEventListener('load',callFlashcardApi);

let resp;

//assign the returned json to the resp variable
async function callFlashcardApi(){
}

//manipulate the dom with this function
function manipDom(){
}

//this returns the variable that holds the json received from the api
function getResp(){
    return resp;
}
