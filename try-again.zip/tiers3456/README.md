# REVASSESS
**INSTRUCTIONS:**

You can find the instructions for each tier in the corresponding
markdown files.

Complete the remaining tiers in this branch with the current project.
The tests will run for each tier so do not move on to the next without
getting the appropriate amount of points. Moving on without finishing
the prior tier will result in points not being awarded.

This is a war application so all html, css and js files are located inside 
src/main/webapp folder. It is vital you do not rename the files or move
their location. There is documentation inside the files detailing what
can and can not be changed. 