package com.revature.tier1;

public class SumOverArray {

	public static int IterateAndSum(int[] arr) {
		return 0;
	}
}
