package com.revature.tier1;

public class CompareStrings {

    public static boolean compareStrings(String s1, String s2){
        return false;
    }
}