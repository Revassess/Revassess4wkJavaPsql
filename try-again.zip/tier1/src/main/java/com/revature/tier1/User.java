package com.revature.tier1;

public class User {
}
